export default function Login() {
  return (
    <div>
      <a href="http://localhost:8000/auth/google">
        <button>Login</button>
      </a>
    </div>
  );
}
