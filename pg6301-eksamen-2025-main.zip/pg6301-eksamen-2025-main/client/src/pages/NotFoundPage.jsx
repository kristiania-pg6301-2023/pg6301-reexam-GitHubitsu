export default function NotFoundPage() {
  return (
    <>
      <h1>Siden ikke funnet</h1>
      <p>Lenken du klikket for å komme hit, fungerer ikke...</p>
    </>
  );
}
