export default function AboutPage() {
  return (
    <>
      <h1>Litt om denne siden</h1>
      <p>
        Dette er et sosialt medie der alle som vil kan bidra med sitt. Det
        eneste vi krever av våre brukere er at man registrerer seg før man får
        mulighet til å bidra med egne innlegg.
        <br />
        <br />
        Registrere seg gjør man via konto hos Google
      </p>
    </>
  );
}
